import os

print("os-release: %s" % os.system("cat /etc/os-release"))
