from .cli import run

run()
